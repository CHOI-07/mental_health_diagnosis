# %% 라이브러리 임포트 및 한글 폰트 설정
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import platform
from pathlib import Path

# 한글 폰트 설정
if platform.system() == 'Darwin':
    plt.rcParams['font.family'] = 'AppleGothic'
elif platform.system() == 'Windows':
    plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False

# %% 경로 설정 및 파일명 정리 함수
base_dir_mac = Path.home() / "Desktop/ME/1.re_project/정신건강_자가진단"
base_dir_win = Path("C:/Users/hhhey/Desktop/ME/1.re_project/정신건강_자가진단")
base_dir = base_dir_mac if base_dir_mac.exists() else base_dir_win

data_path = base_dir / "0.preprocessing" / "mental_train_preprocessed.csv"
save_dir = base_dir / "2.visualization"
save_dir.mkdir(parents=True, exist_ok=True)

# 슬래시 등 파일명에 위험한 문자 제거
def sanitize_filename(s):
    return s.replace("/", "_").replace("?", "").replace(":", "").replace(" ", "_")

# %% 데이터 로드 및 id 제거
df = pd.read_csv(data_path)
if 'id' in df.columns:
    df.drop(columns=['id'], inplace=True)

# %% 상관계수 히트맵 (피어슨)
plt.figure(figsize=(12, 10))
corr = df.corr(numeric_only=True)
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", square=True, vmin=-1, vmax=1)
plt.title("변수 간 상관관계 분석", fontsize=14)
plt.tight_layout()
plt.savefig(save_dir / "3_variable_correlation_heatmap.png")
plt.close()

# %% 수치형 변수 분포 시각화
numeric_cols = df.select_dtypes(include='number').columns
for col in numeric_cols:
    plt.figure(figsize=(6, 4))
    sns.histplot(df[col], kde=True, bins=30, color="#3d4e62")
    plt.title(f"{col} 분포", fontsize=12)
    plt.tight_layout()
    filename = sanitize_filename(f"3_hist_{col}.png")
    plt.savefig(save_dir / filename)
    plt.close()

# %% Depression과 주요 변수 boxplot
target = "Depression"
for col in df.columns:
    if col != target and df[col].nunique() > 1 and df[col].nunique() < 15:
        plt.figure(figsize=(6, 4))
        sns.boxplot(x=target, y=col, data=df, palette=["#f8dcde", "#3d4e62"])
        plt.title(f"{col} vs {target} Boxplot", fontsize=12)
        plt.tight_layout()
        filename = sanitize_filename(f"3_boxplot_{col}_vs_{target}.png")
        plt.savefig(save_dir / filename)
        plt.close()

# %% pairplot (샘플 변수)
pair_cols = ["Depression", "Age", "Pressure", "Satisfaction", "Sleep Duration"]
sns.pairplot(df[pair_cols], diag_kind="kde", corner=True)
plt.tight_layout()
plt.savefig(save_dir / "3_pairplot_selected.png")
plt.close()

# %% 범주형 변수별 Depression 비율
categorical_cols = df.select_dtypes(include='object').columns.tolist()
for col in categorical_cols:
    if df[col].nunique() <= 10:
        plt.figure(figsize=(6, 4))
        prop_df = df.groupby(col)[target].value_counts(normalize=True).rename("ratio").reset_index()
        sns.barplot(x=col, y="ratio", hue=target, data=prop_df, palette=["#f8dcde", "#3d4e62"])
        plt.title(f"{col}별 {target} 비율", fontsize=12)
        plt.tight_layout()
        filename = sanitize_filename(f"3_ratio_{col}_vs_{target}.png")
        plt.savefig(save_dir / filename)
        plt.close()

# %% 그룹별 수치형 변수 평균 막대그래프
mean_df = df.groupby(target)[numeric_cols].mean().T
mean_df.plot(kind="bar", figsize=(10, 6), colormap="Pastel1")
plt.title(f"{target} 그룹별 수치형 변수 평균 비교", fontsize=14)
plt.ylabel("평균값")
plt.tight_layout()
plt.savefig(save_dir / "3_mean_numeric_by_depression.png")
plt.close()

# %% 스피어만 상관계수 히트맵
plt.figure(figsize=(12, 10))
spearman_corr = df.corr(method="spearman", numeric_only=True)
sns.heatmap(spearman_corr, annot=True, fmt=".2f", cmap="vlag", square=True, vmin=-1, vmax=1)
plt.title("Spearman 상관관계 분석", fontsize=14)
plt.tight_layout()
plt.savefig(save_dir / "3_variable_spearman_corr_heatmap.png")
plt.close()

# %% 변수 간 클러스터맵
sns.clustermap(corr, annot=True, fmt=".2f", cmap="coolwarm", figsize=(12, 12))
plt.savefig(save_dir / "3_variable_cluster_map.png")
plt.close()

# %% Depression 분포 (Pie chart)
plt.figure(figsize=(5, 4))
df[target].value_counts().plot.pie(autopct="%.1f%%", startangle=90, colors=["#f8dcde", "#8a8a8a"])
plt.title("Depression 타겟 분포", fontsize=12)
plt.ylabel("")
plt.tight_layout()
plt.savefig(save_dir / "3_target_distribution_pie.png")
plt.close()

# %% 전체 변수 간 상관 히트맵 (인코딩 포함)
plt.figure(figsize=(16, 14))
corr_all = df.corr(numeric_only=True)
sns.heatmap(corr_all, annot=False, cmap="coolwarm", square=False, vmin=-1, vmax=1)
plt.title("전체 변수 간 상관관계 히트맵", fontsize=16)
plt.tight_layout()
plt.savefig(save_dir / "3_variable_all_correlation_heatmap.png")
plt.close()

# %% 전체 변수 클러스터맵
sns.clustermap(corr_all, cmap="coolwarm", figsize=(16, 16))
plt.savefig(save_dir / "3_variable_all_cluster_map.png")
plt.close()
